import os
import shutil
from tkinter import filedialog, messagebox
import pygame
import time
import tempfile

pygame.mixer.pre_init(44100, -16, 2, 4096)
pygame.mixer.init()

class FileOperations:
    def __init__(self, carpeta_sonidos="Sonido", carpeta_imagenes="Imagenes"):
        self.CARPETA_SONIDOS = carpeta_sonidos
        self.CARPETA_IMAGENES = carpeta_imagenes
        self.current_audio_file = None
        self.temp_files = []  # Lista para mantener archivos temporales
        
        # Crear carpetas si no existen
        for carpeta in [self.CARPETA_SONIDOS, self.CARPETA_IMAGENES]:
            try:
                if not os.path.exists(carpeta):
                    os.makedirs(carpeta)
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo crear la carpeta {carpeta}: {str(e)}")

        if not pygame.mixer.get_init():
            self.initialize_audio()

    def initialize_audio(self):
        """Inicializa/reinicia el sistema de audio de Pygame"""
        try:
            pygame.mixer.quit()
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=4096)
            return True
        except Exception as e:
            messagebox.showerror("Error de Audio", f"No se pudo inicializar el sistema de audio: {str(e)}")
            return False

    def select_audio_file(self):
        """Selecciona y copia a temporal un archivo de audio"""
        filetypes = [
            ('Archivos de audio', '*.wav *.mp3 *.ogg'),
            ('Archivos WAV', '*.wav'),
            ('Archivos MP3', '*.mp3'), 
            ('Archivos OGG', '*.ogg'),
            ('Todos los archivos', '*.*')
        ]
        
        try:
            archivo = filedialog.askopenfilename(
                title='Seleccionar archivo de audio',
                filetypes=filetypes
            )
            
            if not archivo:
                return None
                
            # Validar archivo seleccionado
            if not self.validate_file(archivo):
                return None
                
            # Crear copia temporal del archivo
            temp_dir = tempfile.gettempdir()
            temp_filename = os.path.join(temp_dir, os.path.basename(archivo))
            
            # Si el archivo temporal ya existe, agregar sufijo
            counter = 1
            while os.path.exists(temp_filename):
                name, ext = os.path.splitext(os.path.basename(archivo))
                temp_filename = os.path.join(temp_dir, f"{name}_{counter}{ext}")
                counter += 1
                
            # Copiar a ubicación temporal
            try:
                shutil.copy2(archivo, temp_filename)
                self.temp_files.append(temp_filename)  # Registrar archivo temporal
                return temp_filename
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo crear copia temporal: {str(e)}")
                return None
                
        except Exception as e:
            messagebox.showerror("Error", f"Error al seleccionar archivo: {str(e)}")
            return None

    def select_image_file(self):
        """Selecciona un archivo de imagen mediante diálogo"""
        filetypes = [('Imágenes', '*.png *.jpg *.jpeg *.gif'), ('Todos los archivos', '*.*')]
        try:
            archivo = filedialog.askopenfilename(title='Seleccionar imagen', filetypes=filetypes)
            
            if not archivo:
                return None
                
            if not self.validate_file(archivo):
                return None
                
            return archivo
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al seleccionar imagen: {str(e)}")
            return None

    def validate_file(self, filepath):
        """Valida que un archivo exista y sea accesible"""
        try:
            if not os.path.exists(filepath):
                messagebox.showerror("Error", "El archivo seleccionado no existe")
                return False
                
            if not os.path.isfile(filepath):
                messagebox.showerror("Error", "La ruta no corresponde a un archivo válido")
                return False
                
            if not os.access(filepath, os.R_OK):
                messagebox.showerror("Error", "No se tiene permiso para leer el archivo")
                return False
                
            return True
        except Exception as e:
            messagebox.showerror("Error", f"Error validando archivo: {str(e)}")
            return False

    def copy_file_safely(self, src, dst):
        """Copia un archivo de manera segura con manejo de errores"""
        try:
            # Verificar archivo fuente
            if not self.validate_file(src):
                return False
                
            # Verificar directorio destino
            dst_dir = os.path.dirname(dst)
            if not os.path.exists(dst_dir):
                os.makedirs(dst_dir)
                
            if not os.access(dst_dir, os.W_OK):
                raise PermissionError(f"No se puede escribir en el directorio destino: {dst_dir}")
                
            # Realizar la copia
            shutil.copy2(src, dst)
            
            # Verificar que la copia fue exitosa
            if not os.path.exists(dst):
                raise RuntimeError("La copia falló sin errores aparentes")
                
            return True
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al copiar archivo:\n{str(e)}")
            return False

    def play_audio(self, sample, stop_current=True):
        """Reproduce un archivo de audio con manejo robusto de errores"""
        if not sample or "archivo_audio" not in sample:
            return False

        ruta = os.path.join(self.CARPETA_SONIDOS, sample["archivo_audio"])
        
        # Validaciones del archivo
        if not self.validate_file(ruta):
            return False
            
        try:
            if not pygame.mixer.get_init():
                if not self.initialize_audio():
                    return False
            
            if stop_current:
                self.stop_audio()  
                
            pygame.mixer.music.load(ruta)
            pygame.mixer.music.play()
            self.current_audio_file = ruta 
            return True
            
        except pygame.error as e:
            error_msg = str(e)
            if "Unrecognized audio format" in error_msg or "Unknown wave format" in error_msg:
                messagebox.showerror("Error", 
                    f"Formato de audio no soportado: {os.path.basename(ruta)}\n"
                    "Formatos soportados: WAV, MP3, OGG")
            else:
                messagebox.showerror("Error", f"No se pudo reproducir: {error_msg}")
            
            self.initialize_audio()
            return False
            
        except Exception as e:
            messagebox.showerror("Error", f"Error inesperado: {str(e)}")
            return False

    def stop_audio(self):
        """Detiene la reproducción y libera recursos del archivo actual"""
        try:
            if pygame.mixer.get_init():
                pygame.mixer.music.stop()
                pygame.mixer.music.unload()  
                self.current_audio_file = None
                time.sleep(0.1)
        except Exception as e:
            print(f"Error deteniendo audio: {e}")

    def release_audio_resources(self):
        """Libera todos los recursos de audio para operaciones con archivos"""
        self.stop_audio() 
        if pygame.mixer.get_init():
            try:
                pygame.mixer.music.fadeout(100)
                time.sleep(0.2)
            except:
                pass

    def force_delete_file(self, filepath, max_attempts=3):
        """
        Intenta eliminar un archivo con múltiples intentos
        y manejo de archivos bloqueados
        """
        if not os.path.exists(filepath):
            return True
            
        if self.current_audio_file and os.path.samefile(filepath, self.current_audio_file):
            self.release_audio_resources()
        
        for attempt in range(max_attempts):
            try:
                os.remove(filepath)
                return True
            except PermissionError:
                if attempt == max_attempts - 1: 
                    return False
                self.release_audio_resources()
                time.sleep(0.3 * (attempt + 1))
            except Exception as e:
                print(f"Intento {attempt + 1} fallido: {str(e)}")
                time.sleep(0.2)
        
        return False

    def cleanup_temp_files(self):
        """Limpia los archivos temporales creados"""
        for temp_file in self.temp_files:
            try:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
            except Exception as e:
                print(f"No se pudo eliminar archivo temporal {temp_file}: {str(e)}")
        self.temp_files = []

    def __del__(self):
        """Destructor para limpiar archivos temporales"""
        self.cleanup_temp_files()