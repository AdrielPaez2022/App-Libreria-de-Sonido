import os
import shutil
from tkinter import filedialog, messagebox
import pygame
import time


pygame.mixer.pre_init(44100, -16, 2, 4096)  
pygame.mixer.init()

class FileOperations:
    def __init__(self, carpeta_sonidos="Sonido", carpeta_imagenes="Imagenes"):
        self.CARPETA_SONIDOS = carpeta_sonidos
        self.CARPETA_IMAGENES = carpeta_imagenes
        self.current_audio_file = None  
        
  
        for carpeta in [self.CARPETA_SONIDOS, self.CARPETA_IMAGENES]:
            if not os.path.exists(carpeta):
                os.makedirs(carpeta)
        

        if not pygame.mixer.get_init():
            self.initialize_audio()

    def initialize_audio(self):
        """Inicializa/reinicia el sistema de audio de Pygame"""
        try:
            pygame.mixer.quit()
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=4096)
            return True
        except Exception as e:
            messagebox.showerror("Error de Audio", f"No se pudo inicializar el sistema de audio: {str(e)}")
            return False

    def select_audio_file(self):
        """Selecciona un archivo de audio mediante diálogo"""
        filetypes = [
            ('Archivos de audio', '*.wav *.mp3 *.ogg'),
            ('Archivos WAV', '*.wav'),
            ('Archivos MP3', '*.mp3'), 
            ('Archivos OGG', '*.ogg'),
            ('Todos los archivos', '*.*')
        ]
        
        archivo = filedialog.askopenfilename(
            title='Seleccionar archivo de audio',
            filetypes=filetypes
        )
        
        if archivo:
            ext = os.path.splitext(archivo)[1].lower()
            if ext not in ['.wav', '.mp3', '.ogg']:
                messagebox.showwarning(
                    "Formato no soportado",
                    "Se recomienda usar formatos WAV, MP3 u OGG para mejor compatibilidad"
                )
            return archivo
        return None

    def select_image_file(self):
        """Selecciona un archivo de imagen mediante diálogo"""
        filetypes = [('Imágenes', '*.png *.jpg *.jpeg *.gif'), ('Todos los archivos', '*.*')]
        archivo = filedialog.askopenfilename(title='Seleccionar imagen', filetypes=filetypes)
        return archivo if archivo else None

    def play_audio(self, sample, stop_current=True):
        """Reproduce un archivo de audio con manejo robusto de errores"""
        if not sample or "archivo_audio" not in sample:
            return False

        ruta = os.path.join(self.CARPETA_SONIDOS, sample["archivo_audio"])
        if not os.path.exists(ruta):
            messagebox.showerror("Error", "El archivo de audio no existe")
            return False
        
        try:

            if not pygame.mixer.get_init():
                if not self.initialize_audio():
                    return False
            
            if stop_current:
                self.stop_audio()  
                
   
            pygame.mixer.music.load(ruta)
            pygame.mixer.music.play()
            self.current_audio_file = ruta 
            return True
            
        except pygame.error as e:
            error_msg = str(e)
            if "Unrecognized audio format" in error_msg or "Unknown wave format" in error_msg:
                messagebox.showerror("Error", 
                    f"Formato de audio no soportado: {os.path.basename(ruta)}\n"
                    "Formatos soportados: WAV, MP3, OGG")
            else:
                messagebox.showerror("Error", f"No se pudo reproducir: {error_msg}")
            

            self.initialize_audio()
            return False
            
        except Exception as e:
            messagebox.showerror("Error", f"Error inesperado: {str(e)}")
            return False

    def stop_audio(self):
        """Detiene la reproducción y libera recursos del archivo actual"""
        try:
            if pygame.mixer.get_init():
                pygame.mixer.music.stop()
                pygame.mixer.music.unload()  
                self.current_audio_file = None
    
                time.sleep(0.1)
        except Exception as e:
            print(f"Error deteniendo audio: {e}")

    def release_audio_resources(self):
        """Libera todos los recursos de audio para operaciones con archivos"""
        self.stop_audio() 
        if pygame.mixer.get_init():
            try:
            
                pygame.mixer.music.fadeout(100)
                time.sleep(0.2)
            except:
                pass

    def force_delete_file(self, filepath, max_attempts=3):
        """
        Intenta eliminar un archivo con múltiples intentos
        y manejo de archivos bloqueados
        """
        if not os.path.exists(filepath):
            return True
            

        if self.current_audio_file and os.path.samefile(filepath, self.current_audio_file):
            self.release_audio_resources()
        
        for attempt in range(max_attempts):
            try:
                os.remove(filepath)
                return True
            except PermissionError:
                if attempt == max_attempts - 1: 
                    return False

                self.release_audio_resources()
                time.sleep(0.3 * (attempt + 1))
            except Exception as e:
                print(f"Intento {attempt + 1} fallido: {str(e)}")
                time.sleep(0.2)
        
        return False

    def safe_file_operations(self, func, filepath, *args, **kwargs):
        """
        Ejecuta operaciones con archivos de manera segura,
        liberando recursos de audio si es necesario
        """
        self.release_audio_resources()
        try:
            return func(filepath, *args, **kwargs)
        except PermissionError:
            time.sleep(0.2)
            self.release_audio_resources()
            try:
                return func(filepath, *args, **kwargs)
            except Exception as e:
                raise e