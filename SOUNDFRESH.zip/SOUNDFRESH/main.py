import os
from tkinter import *
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
from Database import Database
from CRUDOperations import CRUDOperations
from file_operations import FileOperations
from waveform import WaveformCanvas
import pygame

class SoundFreshApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SOUNDFRESH - Gestor de Samples")
        self.root.geometry("1200x800")
        self.root.configure(bg='#121212')
        
        # Inicializar componentes en el orden correcto
        self.file_ops = FileOperations()  # Primero FileOperations
        self.db = Database()             # Luego Database
        self.crud = CRUDOperations(self.db, self.file_ops)  # Finalmente CRUD con ambos parámetros
        
        # Variables de estado
        self.currently_playing = None
        self.archivo_temporal_audio = None
        self.archivo_temporal_imagen = None
        self.sample_actual_id = None
        self.modo_edicion = False
        
        # Variables de control
        self.nombre_sample = StringVar()
        self.nombre_artista = StringVar()
        self.escala = StringVar()
        self.compas = StringVar()
        self.genero = StringVar()
        self.tipo_instrumento = StringVar()
        self.archivo_audio = StringVar(value="Seleccionar archivo...")
        self.archivo_imagen = StringVar(value="Seleccionar imagen...")
        self.busqueda_var = StringVar()
        
        # Inicializar pygame mixer
        pygame.mixer.init()
        
        self.crear_widgets()
        self.setup_search_bar()
        self.mostrar_samples()

    def crear_widgets(self):
        # Frame principal
        main_frame = Frame(self.root, bg='#121212')
        main_frame.pack(fill=BOTH, expand=True, padx=20, pady=20)
        
        # Frame superior (contiene logo, búsqueda y controles)
        self.top_frame = Frame(main_frame, bg='#121212')
        self.top_frame.pack(fill=X, pady=(0, 20))
        
        # Logo
        Label(self.top_frame, text="SOUNDFRESH", font=('Helvetica', 24, 'bold'), 
             fg='#4a90e2', bg='#121212').pack(side=LEFT)
        
        # Controles de reproducción
        controls_frame = Frame(self.top_frame, bg='#121212')
        controls_frame.pack(side=RIGHT)
        
        self.play_btn = Button(controls_frame, text="▶", command=self.reproducir_sample,
                             bg='#4a90e2', fg='white', bd=0)
        self.play_btn.pack(side=LEFT, padx=5)
        
        self.stop_btn = Button(controls_frame, text="■", command=self.detener_reproduccion,
                             bg='#333333', fg='white', bd=0)
        self.stop_btn.pack(side=LEFT, padx=5)
        
        content_frame = Frame(main_frame, bg='#121212')
        content_frame.pack(fill=BOTH, expand=True)
        
        # Frame del formulario (izquierda)
        form_frame = Frame(content_frame, bg='#1a1a1a', padx=15, pady=15)
        form_frame.pack(side=LEFT, fill=Y, padx=(0, 20))
        
        # Campos del formulario
        campos = [
            ("Nombre del Sample:", self.nombre_sample),
            ("Artista:", self.nombre_artista),
            ("Escala:", self.escala),
            ("Compás:", self.compas),
            ("Género:", self.genero),
            ("Instrumento:", self.tipo_instrumento)
        ]
        
        for i, (texto, variable) in enumerate(campos):
            Label(form_frame, text=texto, fg='white', bg='#1a1a1a',
                 font=('Helvetica', 10)).grid(row=i, column=0, sticky="w", pady=5)
            Entry(form_frame, textvariable=variable, font=('Helvetica', 10),
                 bg='#333333', fg='white', insertbackground='white').grid(row=i, column=1, sticky="ew", pady=5)
        
        # Selector de audio
        Label(form_frame, text="Archivo de Audio:", fg='white', bg='#1a1a1a',
             font=('Helvetica', 10)).grid(row=6, column=0, sticky="w", pady=5)
        
        audio_frame = Frame(form_frame, bg='#1a1a1a')
        audio_frame.grid(row=6, column=1, sticky="ew", pady=5)
        
        Entry(audio_frame, textvariable=self.archivo_audio, state='readonly',
             font=('Helvetica', 10), bg='#333333', fg='white').pack(side=LEFT, fill=X, expand=True)
        
        Button(audio_frame, text="Examinar", command=self.seleccionar_audio,
              bg='#4a90e2', fg='white', bd=0).pack(side=RIGHT)
        
        # Selector de imagen
        Label(form_frame, text="Imagen:", fg='white', bg='#1a1a1a',
             font=('Helvetica', 10)).grid(row=7, column=0, sticky="w", pady=5)
        
        img_frame = Frame(form_frame, bg='#1a1a1a')
        img_frame.grid(row=7, column=1, sticky="ew", pady=5)
        
        Entry(img_frame, textvariable=self.archivo_imagen, state='readonly',
             font=('Helvetica', 10), bg='#333333', fg='white').pack(side=LEFT, fill=X, expand=True)
        
        Button(img_frame, text="Examinar", command=self.seleccionar_imagen,
              bg='#4a90e2', fg='white', bd=0).pack(side=RIGHT)
        
        # Botones
        btn_frame = Frame(form_frame, bg='#1a1a1a')
        btn_frame.grid(row=8, column=0, columnspan=2, pady=(20, 0))
        
        self.btn_guardar = Button(btn_frame, text="GUARDAR", command=self.guardar_sample,
                                bg='#4a90e2', fg='white', bd=0)
        self.btn_guardar.pack(side=LEFT, padx=5)
        
        Button(btn_frame, text="LIMPIAR", command=self.limpiar_formulario,
              bg='#333333', fg='white', bd=0).pack(side=LEFT, padx=5)
        
        self.btn_cancelar = Button(btn_frame, text="CANCELAR", command=self.cancelar_edicion,
                                 bg='#ff5555', fg='white', bd=0)
        self.btn_cancelar.pack(side=LEFT, padx=5)
        self.btn_cancelar.pack_forget()
        
        # Frame de visualización (derecha)
        display_frame = Frame(content_frame, bg='#1a1a1a')
        display_frame.pack(side=RIGHT, fill=BOTH, expand=True)
        
        # Canvas de onda de audio
        self.waveform_canvas = WaveformCanvas(display_frame, height=150, bg='#1a1a1a')
        self.waveform_canvas.pack(fill=X, pady=(0, 10))
        
        # Canvas para los samples
        self.canvas = Canvas(display_frame, bg='#1a1a1a', highlightthickness=0)
        scrollbar = ttk.Scrollbar(display_frame, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = Frame(self.canvas, bg='#1a1a1a')
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            )
        )
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

    def setup_search_bar(self):
        """Configura la barra de búsqueda en la interfaz"""
        search_frame = Frame(self.top_frame, bg='#121212')
        search_frame.pack(side=LEFT, expand=True, fill=X, padx=20)
        
        style = ttk.Style()
        style.theme_use('clam') 
        
        style.configure('Search.TEntry', 
                      foreground='white',  
                      fieldbackground='#333333',  
                      insertbackground='white',  
                      borderwidth=1,
                      relief='solid')
        
        self.search_entry = ttk.Entry(search_frame, textvariable=self.busqueda_var, 
                                    style='Search.TEntry', font=('Helvetica', 10))
        self.search_entry.pack(side=LEFT, fill=X, expand=True, padx=(0, 5))
        self.search_entry.insert(0, "Buscar samples...")
        self.search_entry.bind('<FocusIn>', self._clear_search_placeholder)
        self.search_entry.bind('<FocusOut>', self._set_search_placeholder)
        self.search_entry.bind('<KeyRelease>', self._on_search_keyrelease)
        
        search_btn = Button(search_frame, text="Buscar", command=self._perform_search,
                          bg='#4a90e2', fg='white', bd=0)
        search_btn.pack(side=LEFT)

    def _clear_search_placeholder(self, event):
        if self.search_entry.get() == "Buscar samples...":
            self.search_entry.delete(0, END)
            self.search_entry.configure(style='Search.TEntry')

    def _set_search_placeholder(self, event):
        if not self.search_entry.get():
            self.search_entry.insert(0, "Buscar samples...")

    def _on_search_keyrelease(self, event):
        search_term = self.busqueda_var.get()
        if search_term == "Buscar samples...":
            return
        if len(search_term) >= 2 or not search_term:
            self._perform_search()

    def _perform_search(self):
        search_term = self.busqueda_var.get()
        if search_term == "Buscar samples...":
            search_term = ""
        
        if search_term:
            samples = self.crud.search_samples(search_term)
        else:
            samples = self.crud.get_all_samples()
        
        self._display_samples(samples)

    def seleccionar_audio(self):
        self.archivo_temporal_audio = self.file_ops.select_audio_file()
        if self.archivo_temporal_audio:
            self.archivo_audio.set(os.path.basename(self.archivo_temporal_audio))

    def seleccionar_imagen(self):
        self.archivo_temporal_imagen = self.file_ops.select_image_file()
        if self.archivo_temporal_imagen:
            self.archivo_imagen.set(os.path.basename(self.archivo_temporal_imagen))

    def guardar_sample(self):
        if not self.nombre_sample.get():
            messagebox.showerror("Error", "El nombre del sample es obligatorio")
            return
        
        if not self.archivo_temporal_audio:
            messagebox.showerror("Error", "Debe seleccionar un archivo de audio")
            return
        
        sample_data = {
            "nombre_sample": self.nombre_sample.get(),
            "nombre_artista": self.nombre_artista.get(),
            "escala": self.escala.get(),
            "compas": self.compas.get(),
            "genero": self.genero.get(),
            "tipo_instrumento": self.tipo_instrumento.get(),
            "archivo_temporal_audio": self.archivo_temporal_audio,
            "archivo_temporal_imagen": self.archivo_temporal_imagen
        }
        
        if self.modo_edicion:
            success = self.crud.update_sample(self.sample_actual_id, sample_data)
        else:
            success = self.crud.create_sample(sample_data) is not None
        
        if success:
            self.limpiar_formulario()
            self._perform_search()

    def editar_sample(self, sample_id):
        sample = self.crud.get_sample(sample_id)
        if sample:
            self.modo_edicion = True
            self.sample_actual_id = sample_id
            
            self.nombre_sample.set(sample["nombre_sample"])
            self.nombre_artista.set(sample["nombre_artista"])
            self.escala.set(sample["escala"])
            self.compas.set(sample["compas"])
            self.genero.set(sample["genero"])
            self.tipo_instrumento.set(sample["tipo_instrumento"])
            self.archivo_audio.set(sample["archivo_audio"])
            
            self.archivo_temporal_audio = os.path.join(self.file_ops.CARPETA_SONIDOS, sample["archivo_audio"])
            
            if sample.get("archivo_imagen"):
                self.archivo_imagen.set(sample["archivo_imagen"])
                self.archivo_temporal_imagen = os.path.join(self.file_ops.CARPETA_IMAGENES, sample["archivo_imagen"])
            else:
                self.archivo_imagen.set("Seleccionar imagen...")
                self.archivo_temporal_imagen = None
            
            self.btn_guardar.config(text="ACTUALIZAR")
            self.btn_cancelar.pack(side=LEFT, padx=5)

    def eliminar_sample(self, sample_id):
        self.file_ops.stop_audio()
        if self.crud.delete_sample(sample_id):
            self._perform_search()

    def reproducir_sample(self):
        if self.currently_playing:
            pygame.mixer.music.unpause()
        elif self.archivo_temporal_audio:
            self.file_ops.play_audio({"archivo_audio": self.archivo_temporal_audio})

    def reproducir_desde_card(self, sample):
        if self.file_ops.play_audio(sample):
            self.currently_playing = os.path.join(self.file_ops.CARPETA_SONIDOS, sample["archivo_audio"])
            self.play_btn.config(text="❚❚")
            self.waveform_canvas.load_audio(self.currently_playing)

    def detener_reproduccion(self):
        self.file_ops.stop_audio()
        self.play_btn.config(text="▶")
        self.currently_playing = None

    def cancelar_edicion(self):
        self.limpiar_formulario()
        self.btn_cancelar.pack_forget()
        self.btn_guardar.config(text="GUARDAR")
        self.modo_edicion = False
        self.sample_actual_id = None

    def limpiar_formulario(self):
        self.nombre_sample.set("")
        self.nombre_artista.set("")
        self.escala.set("")
        self.compas.set("")
        self.genero.set("")
        self.tipo_instrumento.set("")
        self.archivo_audio.set("Seleccionar archivo...")
        self.archivo_imagen.set("Seleccionar imagen...")
        self.archivo_temporal_audio = None
        self.archivo_temporal_imagen = None

    def mostrar_samples(self):
        self._perform_search()

    def _display_samples(self, samples):
        try:
            # Limpiar el frame de samples
            for widget in self.scrollable_frame.winfo_children():
                widget.destroy()
            
            # Mostrar mensaje si no hay resultados
            if not samples:
                no_results = Label(self.scrollable_frame, text="No se encontraron samples", 
                                 fg='white', bg='#1a1a1a', font=('Helvetica', 12))
                no_results.pack(pady=50)
                return
            
            # Mostrar cada sample
            for i, sample in enumerate(samples):
                card = Frame(self.scrollable_frame, bg='#2a2a2a', bd=2, relief='ridge', padx=10, pady=10)
                card.grid(row=i//3, column=i%3, padx=10, pady=10, sticky="nsew")
                
                # Configurar grid
                self.scrollable_frame.grid_rowconfigure(i//3, weight=1)
                self.scrollable_frame.grid_columnconfigure(i%3, weight=1)
                
                # Mostrar imagen si existe
                if sample.get("archivo_imagen"):
                    try:
                        ruta_imagen = os.path.join(self.file_ops.CARPETA_IMAGENES, sample["archivo_imagen"])
                        if os.path.exists(ruta_imagen):
                            img = Image.open(ruta_imagen)
                            img.thumbnail((200, 200))
                            img_tk = ImageTk.PhotoImage(img)
                            
                            img_label = Label(card, image=img_tk, bg='#2a2a2a')
                            img_label.image = img_tk
                            img_label.pack()
                    except Exception as e:
                        print(f"Error al cargar imagen: {str(e)}")
                
                # Información del sample
                info_frame = Frame(card, bg='#2a2a2a')
                info_frame.pack(fill='x', pady=(5, 0))
                
                Label(info_frame, text=sample["nombre_sample"], 
                     font=('Helvetica', 12, 'bold'), 
                     fg='white', bg='#2a2a2a').pack(anchor='w')
                
                Label(info_frame, text=f"Artista: {sample['nombre_artista']}", 
                     fg='#aaaaaa', bg='#2a2a2a').pack(anchor='w')
                
                # Detalles
                detalles_frame = Frame(info_frame, bg='#2a2a2a')
                detalles_frame.pack(fill='x')
                
                Label(detalles_frame, text=f"Escala: {sample['escala']}", 
                     fg='#aaaaaa', bg='#2a2a2a').pack(side='left', padx=(0, 10))
                Label(detalles_frame, text=f"Compás: {sample['compas']}", 
                     fg='#aaaaaa', bg='#2a2a2a').pack(side='left', padx=(0, 10))
                Label(detalles_frame, text=f"Género: {sample['genero']}", 
                     fg='#aaaaaa', bg='#2a2a2a').pack(side='left')
                
                # Botones
                btn_frame = Frame(card, bg='#2a2a2a')
                btn_frame.pack(fill='x', pady=(5, 0))
                
                Button(btn_frame, text="Reproducir", 
                      command=lambda s=sample: self.reproducir_desde_card(s),
                      bg='#4a90e2', fg='white', bd=0).pack(side='left', padx=(0, 5))
                
                Button(btn_frame, text="Editar", 
                      command=lambda sid=str(sample["_id"]): self.editar_sample(sid),
                      bg='#ffaa00', fg='white', bd=0).pack(side='left', padx=(0, 5))
                
                Button(btn_frame, text="Eliminar", 
                      command=lambda sid=str(sample["_id"]): self.eliminar_sample(sid),
                      bg='#ff5555', fg='white', bd=0).pack(side='left')

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los samples: {str(e)}")

if __name__ == "__main__":
    root = Tk()
    app = SoundFreshApp(root)
    root.mainloop()