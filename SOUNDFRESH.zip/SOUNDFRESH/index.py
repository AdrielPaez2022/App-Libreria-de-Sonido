import os
import shutil
import pygame
import wave
import numpy as np
from tkinter import *
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk
import pymongo
from pymongo import MongoClient
from bson.objectid import ObjectId

pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=4096)
pygame.mixer.pre_init(44100, -16, 2, 4096)
CARPETA_SONIDOS = "Sonido"
CARPETA_IMAGENES = "Imagenes"


for carpeta in [CARPETA_SONIDOS, CARPETA_IMAGENES]:
    if not os.path.exists(carpeta):
        os.makedirs(carpeta)


MONGO_URI = "mongodb://localhost:27017/"
MONGO_DB = "SOUNDFRESH"
MONGO_COLLECTION = "samples"

try:
    client = MongoClient(MONGO_URI)
    db = client[MONGO_DB]
    collection = db[MONGO_COLLECTION]
except Exception as e:
    messagebox.showerror("Error", f"No se pudo conectar a MongoDB: {str(e)}")

class WaveformCanvas(Canvas):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.configure(bg='#1a1a1a', highlightthickness=0)
        self.waveform_data = None
        self.duration = 0
        
    def load_audio(self, filepath):
        try:

            with wave.open(filepath, 'rb') as wav_file:
                frames = wav_file.readframes(-1)
                sound_info = np.frombuffer(frames, dtype=np.int16)
                self.duration = wav_file.getnframes() / wav_file.getframerate()
                self.waveform_data = sound_info[::2]
                self.draw_waveform()
        except:
            try:

                sound = pygame.mixer.Sound(filepath)
                array = pygame.sndarray.array(sound)
                self.waveform_data = array[::1000, 0]
                self.duration = sound.get_length()
                self.draw_waveform()
            except Exception as e:
                print(f"No se pudo cargar waveform: {str(e)}")
                self.waveform_data = None
                self.duration = 0
                self.delete("all")
                self.create_text(self.winfo_width()/2, self.winfo_height()/2, 
                                text="Formato no soportado", fill="white")
    
    def draw_waveform(self):
        self.delete("all")
        if self.waveform_data is None:
            return
            
        width = self.winfo_width()
        height = self.winfo_height()
        center_y = height // 2
        max_amplitude = max(abs(self.waveform_data)) or 1
        
        self.create_line(0, center_y, width, center_y, fill='#333333')
        
        step = max(1, len(self.waveform_data) // width)
        for x in range(width):
            idx = min(x * step, len(self.waveform_data) - 1)
            amplitude = self.waveform_data[idx] / max_amplitude
            y1 = center_y - amplitude * (height // 2) * 0.8
            y2 = center_y + amplitude * (height // 2) * 0.8
            self.create_line(x, y1, x, y2, fill='#4a90e2')

class SoundFreshApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SOUNDFRESH - Gestor de Samples")
        self.root.geometry("1200x800")
        self.root.configure(bg='#121212')
        
        # Variables
        self.nombre_sample = StringVar()
        self.nombre_artista = StringVar()
        self.escala = StringVar()
        self.compas = StringVar()
        self.genero = StringVar()
        self.tipo_instrumento = StringVar()
        self.archivo_audio = StringVar(value="Seleccionar archivo...")
        self.archivo_imagen = StringVar(value="Seleccionar imagen...")
        self.currently_playing = None
        self.archivo_temporal_audio = None
        self.archivo_temporal_imagen = None
        self.sample_actual_id = None
        self.modo_edicion = False
        
        self.crear_widgets()
        self.mostrar_samples()
    
    def crear_widgets(self):
        # Frame principal
        main_frame = Frame(self.root, bg='#121212')
        main_frame.pack(fill=BOTH, expand=True, padx=20, pady=20)
        
        # Frame superior
        top_frame = Frame(main_frame, bg='#121212')
        top_frame.pack(fill=X, pady=(0, 20))
        
        # Logo
        Label(top_frame, text="SOUNDFRESH", font=('Helvetica', 24, 'bold'), 
             fg='#4a90e2', bg='#121212').pack(side=LEFT)
        
        # Controles
        controls_frame = Frame(top_frame, bg='#121212')
        controls_frame.pack(side=RIGHT)
        
        self.play_btn = Button(controls_frame, text="▶", command=self.reproducir_sample,
                             bg='#4a90e2', fg='white', bd=0)
        self.play_btn.pack(side=LEFT, padx=5)
        
        self.stop_btn = Button(controls_frame, text="■", command=self.detener_reproduccion,
                             bg='#333333', fg='white', bd=0)
        self.stop_btn.pack(side=LEFT, padx=5)
        
        # Contenido principal
        content_frame = Frame(main_frame, bg='#121212')
        content_frame.pack(fill=BOTH, expand=True)
        

        form_frame = Frame(content_frame, bg='#1a1a1a', padx=15, pady=15)
        form_frame.pack(side=LEFT, fill=Y, padx=(0, 20))
        

        campos = [
            ("Nombre del Sample:", self.nombre_sample),
            ("Artista:", self.nombre_artista),
            ("Escala:", self.escala),
            ("Compás:", self.compas),
            ("Género:", self.genero),
            ("Instrumento:", self.tipo_instrumento)
        ]
        
        for i, (texto, variable) in enumerate(campos):
            Label(form_frame, text=texto, fg='white', bg='#1a1a1a',
                 font=('Helvetica', 10)).grid(row=i, column=0, sticky="w", pady=5)
            Entry(form_frame, textvariable=variable, font=('Helvetica', 10),
                 bg='#333333', fg='white').grid(row=i, column=1, sticky="ew", pady=5)
        

        Label(form_frame, text="Archivo de Audio:", fg='white', bg='#1a1a1a',
             font=('Helvetica', 10)).grid(row=6, column=0, sticky="w", pady=5)
        
        audio_frame = Frame(form_frame, bg='#1a1a1a')
        audio_frame.grid(row=6, column=1, sticky="ew", pady=5)
        
        Entry(audio_frame, textvariable=self.archivo_audio, state='readonly',
             font=('Helvetica', 10), bg='#333333', fg='white').pack(side=LEFT, fill=X, expand=True)
        
        Button(audio_frame, text="Examinar", command=self.seleccionar_audio,
              bg='#4a90e2', fg='white', bd=0).pack(side=RIGHT)
        

        Label(form_frame, text="Imagen:", fg='white', bg='#1a1a1a',
             font=('Helvetica', 10)).grid(row=7, column=0, sticky="w", pady=5)
        
        img_frame = Frame(form_frame, bg='#1a1a1a')
        img_frame.grid(row=7, column=1, sticky="ew", pady=5)
        
        Entry(img_frame, textvariable=self.archivo_imagen, state='readonly',
             font=('Helvetica', 10), bg='#333333', fg='white').pack(side=LEFT, fill=X, expand=True)
        
        Button(img_frame, text="Examinar", command=self.seleccionar_imagen,
              bg='#4a90e2', fg='white', bd=0).pack(side=RIGHT)
        
        btn_frame = Frame(form_frame, bg='#1a1a1a')
        btn_frame.grid(row=8, column=0, columnspan=2, pady=(20, 0))
        
        self.btn_guardar = Button(btn_frame, text="GUARDAR", command=self.guardar_sample,
                                bg='#4a90e2', fg='white', bd=0)
        self.btn_guardar.pack(side=LEFT, padx=5)
        
        Button(btn_frame, text="LIMPIAR", command=self.limpiar_formulario,
              bg='#333333', fg='white', bd=0).pack(side=LEFT, padx=5)
        
        self.btn_cancelar = Button(btn_frame, text="CANCELAR", command=self.cancelar_edicion,
                                 bg='#ff5555', fg='white', bd=0)
        self.btn_cancelar.pack(side=LEFT, padx=5)
        self.btn_cancelar.pack_forget()
        

        display_frame = Frame(content_frame, bg='#1a1a1a')
        display_frame.pack(side=RIGHT, fill=BOTH, expand=True)
        

        self.waveform_canvas = WaveformCanvas(display_frame, height=150, bg='#1a1a1a')
        self.waveform_canvas.pack(fill=X, pady=(0, 10))
        

        self.canvas = Canvas(display_frame, bg='#1a1a1a', highlightthickness=0)
        scrollbar = ttk.Scrollbar(display_frame, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = Frame(self.canvas, bg='#1a1a1a')
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            )
        )
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
    
    def seleccionar_audio(self):
        filetypes = [
            ('Archivos de audio', '*.wav *.mp3 *.ogg'),
            ('Archivos WAV', '*.wav'),
            ('Archivos MP3', '*.mp3'), 
            ('Archivos OGG', '*.ogg'),
            ('Todos los archivos', '*.*')
        ]
        
        archivo = filedialog.askopenfilename(
            title='Seleccionar archivo de audio',
            filetypes=filetypes
        )
        
        if archivo:
            ext = os.path.splitext(archivo)[1].lower()
            if ext not in ['.wav', '.mp3', '.ogg']:
                messagebox.showwarning(
                    "Formato no soportado",
                    "Se recomienda usar formatos WAV, MP3 u OGG para mejor compatibilidad"
                )
            
            self.archivo_temporal_audio = archivo
            self.archivo_audio.set(os.path.basename(archivo))
    
    def seleccionar_imagen(self):
        filetypes = [('Imágenes', '*.png *.jpg *.jpeg *.gif'), ('Todos los archivos', '*.*')]
        archivo = filedialog.askopenfilename(title='Seleccionar imagen', filetypes=filetypes)
        if archivo:
            self.archivo_temporal_imagen = archivo
            self.archivo_imagen.set(os.path.basename(archivo))
    
    def guardar_sample(self):
        if not self.nombre_sample.get():
            messagebox.showerror("Error", "El nombre del sample es obligatorio")
            return
        
        if not self.archivo_temporal_audio:
            messagebox.showerror("Error", "Debe seleccionar un archivo de audio")
            return
        
        try:

            nombre_archivo_audio = os.path.basename(self.archivo_temporal_audio)
            destino_audio = os.path.join(CARPETA_SONIDOS, nombre_archivo_audio)
            
            if not self.modo_edicion or not os.path.exists(destino_audio):
                counter = 1
                while os.path.exists(destino_audio):
                    nombre, ext = os.path.splitext(nombre_archivo_audio)
                    nombre_archivo_audio = f"{nombre}_{counter}{ext}"
                    destino_audio = os.path.join(CARPETA_SONIDOS, nombre_archivo_audio)
                    counter += 1
                
                shutil.copy2(self.archivo_temporal_audio, destino_audio)
            

            nombre_archivo_imagen = None
            if self.archivo_temporal_imagen:
                nombre_archivo_imagen = os.path.basename(self.archivo_temporal_imagen)
                destino_imagen = os.path.join(CARPETA_IMAGENES, nombre_archivo_imagen)
                
                if not self.modo_edicion or not os.path.exists(destino_imagen):
                    counter = 1
                    while os.path.exists(destino_imagen):
                        nombre, ext = os.path.splitext(nombre_archivo_imagen)
                        nombre_archivo_imagen = f"{nombre}_{counter}{ext}"
                        destino_imagen = os.path.join(CARPETA_IMAGENES, nombre_archivo_imagen)
                        counter += 1
                    
                    shutil.copy2(self.archivo_temporal_imagen, destino_imagen)
            

            sample_data = {
                "nombre_sample": self.nombre_sample.get(),
                "nombre_artista": self.nombre_artista.get(),
                "escala": self.escala.get(),
                "compas": self.compas.get(),
                "genero": self.genero.get(),
                "tipo_instrumento": self.tipo_instrumento.get(),
                "archivo_audio": nombre_archivo_audio,
                "archivo_imagen": nombre_archivo_imagen if self.archivo_temporal_imagen else None
            }
            
            if self.modo_edicion:

                collection.update_one(
                    {"_id": ObjectId(self.sample_actual_id)},
                    {"$set": sample_data}
                )
                messagebox.showinfo("Éxito", "Sample actualizado correctamente")
            else:

                collection.insert_one(sample_data)
                messagebox.showinfo("Éxito", "Sample guardado correctamente")
            
            self.limpiar_formulario()
            self.mostrar_samples()
            
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar: {str(e)}")
    
    def editar_sample(self, sample_id):
        try:
            sample = collection.find_one({"_id": ObjectId(sample_id)})
            if sample:
                self.modo_edicion = True
                self.sample_actual_id = sample_id
                
  
                self.nombre_sample.set(sample["nombre_sample"])
                self.nombre_artista.set(sample["nombre_artista"])
                self.escala.set(sample["escala"])
                self.compas.set(sample["compas"])
                self.genero.set(sample["genero"])
                self.tipo_instrumento.set(sample["tipo_instrumento"])
                self.archivo_audio.set(sample["archivo_audio"])
                

                self.archivo_temporal_audio = os.path.join(CARPETA_SONIDOS, sample["archivo_audio"])
                
                if sample.get("archivo_imagen"):
                    self.archivo_imagen.set(sample["archivo_imagen"])
                    self.archivo_temporal_imagen = os.path.join(CARPETA_IMAGENES, sample["archivo_imagen"])
                else:
                    self.archivo_imagen.set("Seleccionar imagen...")
                    self.archivo_temporal_imagen = None
                

                self.btn_guardar.config(text="ACTUALIZAR")
                self.btn_cancelar.pack(side=LEFT, padx=5)
                
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo cargar el sample: {str(e)}")
    
    def eliminar_sample(self, sample_id):
        try:
            respuesta = messagebox.askyesno(
                "Confirmar eliminación",
                "¿Estás seguro de que quieres eliminar este sample? Esta acción no se puede deshacer."
            )
            
            if respuesta:
                sample = collection.find_one({"_id": ObjectId(sample_id)})
                if sample:

                    if sample.get("archivo_audio"):
                        archivo_audio = os.path.join(CARPETA_SONIDOS, sample["archivo_audio"])
                        if os.path.exists(archivo_audio):
                            os.remove(archivo_audio)
                    
                    if sample.get("archivo_imagen"):
                        archivo_imagen = os.path.join(CARPETA_IMAGENES, sample["archivo_imagen"])
                        if os.path.exists(archivo_imagen):
                            os.remove(archivo_imagen)
                    

                    collection.delete_one({"_id": ObjectId(sample_id)})
                    messagebox.showinfo("Éxito", "Sample eliminado correctamente")
                    self.mostrar_samples()
                
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo eliminar el sample: {str(e)}")
    
    def cancelar_edicion(self):
        self.limpiar_formulario()
        self.btn_cancelar.pack_forget()
        self.btn_guardar.config(text="GUARDAR")
        self.modo_edicion = False
        self.sample_actual_id = None
    
    def limpiar_formulario(self):
        self.nombre_sample.set("")
        self.nombre_artista.set("")
        self.escala.set("")
        self.compas.set("")
        self.genero.set("")
        self.tipo_instrumento.set("")
        self.archivo_audio.set("Seleccionar archivo...")
        self.archivo_imagen.set("Seleccionar imagen...")
        self.archivo_temporal_audio = None
        self.archivo_temporal_imagen = None
    
    def mostrar_samples(self):
        try:

            for widget in self.scrollable_frame.winfo_children():
                widget.destroy()
            

            samples = collection.find()

            for i, sample in enumerate(samples):
                card = Frame(self.scrollable_frame, bg='#2a2a2a', bd=2, relief='ridge', padx=10, pady=10)
                card.grid(row=i//3, column=i%3, padx=10, pady=10, sticky="nsew")
                

                self.scrollable_frame.grid_rowconfigure(i//3, weight=1)
                self.scrollable_frame.grid_columnconfigure(i%3, weight=1)
                

                if sample.get("archivo_imagen"):
                    try:
                        ruta_imagen = os.path.join(CARPETA_IMAGENES, sample["archivo_imagen"])
                        if os.path.exists(ruta_imagen):
                            img = Image.open(ruta_imagen)
                            img.thumbnail((200, 200))
                            img_tk = ImageTk.PhotoImage(img)
                            
                            img_label = Label(card, image=img_tk, bg='#2a2a2a')
                            img_label.image = img_tk
                            img_label.pack()
                    except Exception as e:
                        print(f"Error al cargar imagen: {str(e)}")
                

                info_frame = Frame(card, bg='#2a2a2a')
                info_frame.pack(fill='x', pady=(5, 0))
                

                Label(info_frame, text=sample["nombre_sample"], 
                     font=('Helvetica', 12, 'bold'), 
                     fg='white', bg='#2a2a2a').pack(anchor='w')
 
                Label(info_frame, text=f"Artista: {sample['nombre_artista']}", 
                     fg='#aaaaaa', bg='#2a2a2a').pack(anchor='w')
                

                detalles_frame = Frame(info_frame, bg='#2a2a2a')
                detalles_frame.pack(fill='x')
                
                Label(detalles_frame, text=f"Escala: {sample['escala']}", 
                     fg='#aaaaaa', bg='#2a2a2a').pack(side='left', padx=(0, 10))
                Label(detalles_frame, text=f"Compás: {sample['compas']}", 
                     fg='#aaaaaa', bg='#2a2a2a').pack(side='left', padx=(0, 10))
                Label(detalles_frame, text=f"Género: {sample['genero']}", 
                     fg='#aaaaaa', bg='#2a2a2a').pack(side='left')
                

                btn_frame = Frame(card, bg='#2a2a2a')
                btn_frame.pack(fill='x', pady=(5, 0))
                
                Button(btn_frame, text="Reproducir", 
                      command=lambda s=sample: self.reproducir_desde_card(s),
                      bg='#4a90e2', fg='white', bd=0).pack(side='left', padx=(0, 5))
                
                Button(btn_frame, text="Editar", 
                      command=lambda sid=str(sample["_id"]): self.editar_sample(sid),
                      bg='#ffaa00', fg='white', bd=0).pack(side='left', padx=(0, 5))
                
                Button(btn_frame, text="Eliminar", 
                      command=lambda sid=str(sample["_id"]): self.eliminar_sample(sid),
                      bg='#ff5555', fg='white', bd=0).pack(side='left')
                
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los samples: {str(e)}")
    
    def reproducir_desde_card(self, sample):
        ruta = os.path.join(CARPETA_SONIDOS, sample["archivo_audio"])
        if not os.path.exists(ruta):
            messagebox.showerror("Error", "El archivo de audio no existe")
            return
        
        try:

            pygame.mixer.music.stop()
            

            pygame.mixer.music.load(ruta)
            pygame.mixer.music.play()
            

            self.currently_playing = ruta
            self.play_btn.config(text="❚❚")
            self.waveform_canvas.load_audio(ruta)
            
        except pygame.error as e:
            error_msg = str(e)
            if "Unrecognized audio format" in error_msg or "Unknown wave format" in error_msg:
                messagebox.showerror("Error", 
                    f"Formato de audio no soportado: {os.path.basename(ruta)}\n"
                    "Formatos soportados: WAV, MP3, OGG")
            else:
                messagebox.showerror("Error", f"No se pudo reproducir: {error_msg}")
        except Exception as e:
            messagebox.showerror("Error", f"Error inesperado: {str(e)}")
    
    def reproducir_sample(self):
 
        pass
    
    def detener_reproduccion(self):
        pygame.mixer.music.stop()
        self.play_btn.config(text="▶")
        self.currently_playing = None

if __name__ == "__main__":
    root = Tk()
    app = SoundFreshApp(root)
    root.mainloop()