import wave
import numpy as np
import pygame
from tkinter import Canvas

class WaveformCanvas(Canvas):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.configure(bg='#1a1a1a', highlightthickness=0)
        self.waveform_data = None
        self.duration = 0
        
    def load_audio(self, filepath):
        try:
            with wave.open(filepath, 'rb') as wav_file:
                frames = wav_file.readframes(-1)
                sound_info = np.frombuffer(frames, dtype=np.int16)
                self.duration = wav_file.getnframes() / wav_file.getframerate()
                self.waveform_data = sound_info[::2]
                self.draw_waveform()
        except:
            try:
                sound = pygame.mixer.Sound(filepath)
                array = pygame.sndarray.array(sound)
                self.waveform_data = array[::1000, 0]
                self.duration = sound.get_length()
                self.draw_waveform()
            except Exception as e:
                print(f"No se pudo cargar waveform: {str(e)}")
                self.waveform_data = None
                self.duration = 0
                self.delete("all")
                self.create_text(self.winfo_width()/2, self.winfo_height()/2, 
                                text="Formato no soportado", fill="white")
    
    def draw_waveform(self):
        self.delete("all")
        if self.waveform_data is None:
            return
            
        width = self.winfo_width()
        height = self.winfo_height()
        center_y = height // 2
        max_amplitude = max(abs(self.waveform_data)) or 1
        
        self.create_line(0, center_y, width, center_y, fill='#333333')
        
        step = max(1, len(self.waveform_data) // width)
        for x in range(width):
            idx = min(x * step, len(self.waveform_data) - 1)
            amplitude = self.waveform_data[idx] / max_amplitude
            y1 = center_y - amplitude * (height // 2) * 0.8
            y2 = center_y + amplitude * (height // 2) * 0.8
            self.create_line(x, y1, x, y2, fill='#4a90e2')