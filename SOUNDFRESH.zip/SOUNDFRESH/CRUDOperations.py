from bson.objectid import ObjectId
from tkinter import messagebox
import os
import shutil
import time

class CRUDOperations:
    def __init__(self, database, file_ops, carpeta_sonidos="Sonido", carpeta_imagenes="Imagenes"):
        self.db = database
        self.file_ops = file_ops
        self.CARPETA_SONIDOS = carpeta_sonidos
        self.CARPETA_IMAGENES = carpeta_imagenes
        self._crear_carpetas_si_no_existen()

    def _crear_carpetas_si_no_existen(self):
        """Crea las carpetas necesarias si no existen"""
        try:
            if not os.path.exists(self.CARPETA_SONIDOS):
                os.makedirs(self.CARPETA_SONIDOS)
            if not os.path.exists(self.CARPETA_IMAGENES):
                os.makedirs(self.CARPETA_IMAGENES)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron crear las carpetas: {str(e)}")

    def create_sample(self, sample_data):
        try:
            if not sample_data.get("nombre_sample"):
                messagebox.showerror("Error", "El nombre del sample es obligatorio")
                return None

            if not sample_data.get("archivo_temporal_audio"):
                messagebox.showerror("Error", "Debe seleccionar un archivo de audio")
                return None

            audio_path = sample_data["archivo_temporal_audio"]
            if not os.path.exists(audio_path):
                messagebox.showerror("Error", "El archivo de audio seleccionado no existe")
                return None

            # Procesamiento de audio
            nombre_audio = os.path.basename(audio_path)
            destino_audio = os.path.join(self.CARPETA_SONIDOS, nombre_audio)
            
            counter = 1
            while os.path.exists(destino_audio):
                nombre, ext = os.path.splitext(nombre_audio)
                nombre_audio = f"{nombre}_{counter}{ext}"
                destino_audio = os.path.join(self.CARPETA_SONIDOS, nombre_audio)
                counter += 1
            
            try:
                shutil.copy2(audio_path, destino_audio)
            except Exception as e:
                messagebox.showerror("Error", f"Error al copiar el archivo de audio: {str(e)}")
                return None
            
            # Procesamiento de imagen
            nombre_imagen = None
            if "archivo_temporal_imagen" in sample_data and sample_data["archivo_temporal_imagen"]:
                imagen_path = sample_data["archivo_temporal_imagen"]
                
                if not os.path.exists(imagen_path):
                    messagebox.showerror("Error", f"El archivo de imagen no existe en:\n{imagen_path}")
                    # Eliminar el audio ya copiado
                    try:
                        os.remove(destino_audio)
                    except:
                        pass
                    return None
                
                if not os.path.isfile(imagen_path):
                    messagebox.showerror("Error", "La ruta especificada no es un archivo válido")
                    try:
                        os.remove(destino_audio)
                    except:
                        pass
                    return None

                nombre_imagen = os.path.basename(imagen_path)
                destino_imagen = os.path.join(self.CARPETA_IMAGENES, nombre_imagen)
                
                counter = 1
                while os.path.exists(destino_imagen):
                    nombre, ext = os.path.splitext(nombre_imagen)
                    nombre_imagen = f"{nombre}_{counter}{ext}"
                    destino_imagen = os.path.join(self.CARPETA_IMAGENES, nombre_imagen)
                    counter += 1
                
                try:
                    shutil.copy2(imagen_path, destino_imagen)
                except Exception as e:
                    messagebox.showerror("Error", f"Error al copiar el archivo de imagen: {str(e)}")
                    try:
                        os.remove(destino_audio)
                    except:
                        pass
                    return None

            sample_db = {
                "nombre_sample": sample_data["nombre_sample"],
                "nombre_artista": sample_data.get("nombre_artista", ""),
                "escala": sample_data.get("escala", ""),
                "compas": sample_data.get("compas", ""),
                "genero": sample_data.get("genero", ""),
                "tipo_instrumento": sample_data.get("tipo_instrumento", ""),
                "archivo_audio": nombre_audio,
                "archivo_imagen": nombre_imagen,
                "fecha_creacion": time.time(),
                "ultima_actualizacion": time.time()
            }

            result = self.db.collection.insert_one(sample_db)
            messagebox.showinfo("Éxito", "Sample creado correctamente")
            return result.inserted_id

        except Exception as e:
            messagebox.showerror("Error", f"Error al crear sample: {str(e)}")
            return None

    def update_sample(self, sample_id, sample_data):
        try:
            if not sample_data.get("nombre_sample"):
                messagebox.showerror("Error", "El nombre del sample es obligatorio")
                return False

            sample_actual = self.db.collection.find_one({"_id": ObjectId(sample_id)})
            if not sample_actual:
                messagebox.showerror("Error", "El sample a actualizar no existe")
                return False
            
            # Procesamiento del archivo de audio
            nombre_audio = sample_actual["archivo_audio"]
            audio_temp_path = sample_data.get("archivo_temporal_audio")
            
            # Si hay un nuevo archivo de audio
            if audio_temp_path:
                # 1. Validar primero el archivo temporal
                if not os.path.exists(audio_temp_path):
                    messagebox.showerror("Error", "El archivo de audio temporal no existe")
                    return False
                
                if not os.path.isfile(audio_temp_path):
                    messagebox.showerror("Error", "El archivo de audio temporal no es válido")
                    return False
                
                # 2. Preparar nuevo nombre y destino
                nombre_audio = os.path.basename(audio_temp_path)
                destino_audio = os.path.join(self.CARPETA_SONIDOS, nombre_audio)
                
                # Manejar nombres duplicados
                counter = 1
                while os.path.exists(destino_audio):
                    nombre, ext = os.path.splitext(nombre_audio)
                    nombre_audio = f"{nombre}_{counter}{ext}"
                    destino_audio = os.path.join(self.CARPETA_SONIDOS, nombre_audio)
                    counter += 1
                
                # 3. Copiar el nuevo archivo primero
                try:
                    shutil.copy2(audio_temp_path, destino_audio)
                except Exception as e:
                    messagebox.showerror("Error", f"No se pudo copiar el nuevo archivo: {str(e)}")
                    return False
                
                # 4. Eliminar el archivo antiguo solo después de copiar el nuevo
                old_path = os.path.join(self.CARPETA_SONIDOS, sample_actual["archivo_audio"])
                if os.path.exists(old_path):
                    try:
                        os.remove(old_path)
                    except Exception as e:
                        messagebox.showwarning("Advertencia", 
                            f"No se pudo eliminar el archivo antiguo: {str(e)}\n"
                            "El nuevo archivo se ha guardado correctamente.")

            # Procesamiento del archivo de imagen
            nombre_imagen = sample_actual.get("archivo_imagen")
            imagen_temp_path = sample_data.get("archivo_temporal_imagen")
            
            if imagen_temp_path is not None:  # None significa eliminar, "" significa mantener
                if imagen_temp_path:  # Nuevo archivo
                    if not os.path.exists(imagen_temp_path):
                        messagebox.showerror("Error", f"El archivo de imagen no existe en:\n{imagen_temp_path}")
                        return False
                    
                    if not os.path.isfile(imagen_temp_path):
                        messagebox.showerror("Error", "La ruta de imagen no es un archivo válido")
                        return False

                    nombre_imagen = os.path.basename(imagen_temp_path)
                    destino_imagen = os.path.join(self.CARPETA_IMAGENES, nombre_imagen)
                    
                    counter = 1
                    while os.path.exists(destino_imagen):
                        nombre, ext = os.path.splitext(nombre_imagen)
                        nombre_imagen = f"{nombre}_{counter}{ext}"
                        destino_imagen = os.path.join(self.CARPETA_IMAGENES, nombre_imagen)
                        counter += 1
                    
                    try:
                        shutil.copy2(imagen_temp_path, destino_imagen)
                    except Exception as e:
                        messagebox.showerror("Error", f"Error al copiar la nueva imagen: {str(e)}")
                        return False
                    
                    # Eliminar imagen anterior si existe
                    if sample_actual.get("archivo_imagen"):
                        old_img_path = os.path.join(self.CARPETA_IMAGENES, sample_actual["archivo_imagen"])
                        if os.path.exists(old_img_path):
                            try:
                                os.remove(old_img_path)
                            except:
                                pass
                else:  # Cadena vacía significa eliminar imagen
                    if sample_actual.get("archivo_imagen"):
                        old_img_path = os.path.join(self.CARPETA_IMAGENES, sample_actual["archivo_imagen"])
                        if os.path.exists(old_img_path):
                            try:
                                os.remove(old_img_path)
                            except:
                                pass
                    nombre_imagen = None

            # Actualizar datos en la base de datos
            update_data = {
                "nombre_sample": sample_data["nombre_sample"],
                "nombre_artista": sample_data.get("nombre_artista", sample_actual.get("nombre_artista", "")),
                "escala": sample_data.get("escala", sample_actual.get("escala", "")),
                "compas": sample_data.get("compas", sample_actual.get("compas", "")),
                "genero": sample_data.get("genero", sample_actual.get("genero", "")),
                "tipo_instrumento": sample_data.get("tipo_instrumento", sample_actual.get("tipo_instrumento", "")),
                "ultima_actualizacion": time.time()
            }

            # Actualizar campos de archivos solo si cambiaron
            if "archivo_temporal_audio" in sample_data and sample_data["archivo_temporal_audio"]:
                update_data["archivo_audio"] = nombre_audio
            
            if "archivo_temporal_imagen" in sample_data:
                update_data["archivo_imagen"] = nombre_imagen

            result = self.db.collection.update_one(
                {"_id": ObjectId(sample_id)},
                {"$set": update_data}
            )
            
            if result.modified_count > 0:
                messagebox.showinfo("Éxito", "Sample actualizado correctamente")
                return True
            else:
                messagebox.showinfo("Información", "No se realizaron cambios en el sample")
                return True

        except Exception as e:
            messagebox.showerror("Error", f"Error al actualizar sample: {str(e)}")
            return False

    def delete_sample(self, sample_id):
        try:
            respuesta = messagebox.askyesno(
                "Confirmar eliminación",
                "¿Estás seguro de que quieres eliminar este sample? Esta acción no se puede deshacer."
            )
            
            if not respuesta:
                return False

            sample = self.db.collection.find_one({"_id": ObjectId(sample_id)})
            if not sample:
                messagebox.showerror("Error", "El sample a eliminar no existe")
                return False

            # Eliminar archivos asociados
            success = True
            
            # Manejo de archivo de audio
            if sample.get("archivo_audio"):
                audio_path = os.path.join(self.CARPETA_SONIDOS, sample["archivo_audio"])
                if os.path.exists(audio_path):
                    try:
                        os.remove(audio_path)
                    except PermissionError:
                        messagebox.showerror("Error", 
                            f"No se pudo eliminar el archivo de audio: {audio_path}\n"
                            "Por favor cierra cualquier programa que lo esté usando.")
                        success = False
                    except Exception as e:
                        messagebox.showerror("Error", f"Error al eliminar audio: {str(e)}")
                        success = False
            
            if success and sample.get("archivo_imagen"):
                imagen_path = os.path.join(self.CARPETA_IMAGENES, sample["archivo_imagen"])
                if os.path.exists(imagen_path):
                    try:
                        os.remove(imagen_path)
                    except:
                        pass
            
            if success:
                # Eliminar de MongoDB
                result = self.db.collection.delete_one({"_id": ObjectId(sample_id)})
                if result.deleted_count > 0:
                    messagebox.showinfo("Éxito", "Sample eliminado correctamente")
                    return True
                else:
                    messagebox.showerror("Error", "No se pudo eliminar el sample de la base de datos")
                    return False
            
            return False

        except Exception as e:
            messagebox.showerror("Error", f"Error al eliminar sample: {str(e)}")
            return False
        
    def search_samples(self, search_term):
        try:
            if not search_term or len(search_term.strip()) == 0:
                return self.get_all_samples()
                
            search_term = search_term.strip().lower()
            
            regex = {'$regex': f'.*{search_term}.*', '$options': 'i'}
            
            query = {
                '$or': [
                    {'nombre_sample': regex},
                    {'nombre_artista': regex},
                    {'escala': regex},
                    {'compas': regex},
                    {'genero': regex},
                    {'tipo_instrumento': regex},
                    {'archivo_audio': regex}
                ]
            }
            
            return list(self.db.collection.find(query).sort("nombre_sample", 1))
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al buscar samples: {str(e)}")
            return []

    def get_sample(self, sample_id):
        try:
            sample = self.db.collection.find_one({"_id": ObjectId(sample_id)})
            if not sample:
                messagebox.showwarning("Advertencia", "El sample solicitado no existe")
            return sample
        except Exception as e:
            messagebox.showerror("Error", f"Error al obtener sample: {str(e)}")
            return None

    def get_all_samples(self, filtro=None):
        try:
            if filtro:
                return list(self.db.collection.find(filtro).sort("nombre_sample", 1))
            return list(self.db.collection.find().sort("nombre_sample", 1))
        except Exception as e:
            messagebox.showerror("Error", f"Error al obtener samples: {str(e)}")
            return []