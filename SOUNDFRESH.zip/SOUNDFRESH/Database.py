from pymongo import MongoClient
from tkinter import messagebox

class Database:
    def __init__(self):
        self.MONGO_URI = "mongodb://localhost:27017/"
        self.MONGO_DB = "SOUNDFRESH"
        self.MONGO_COLLECTION = "samples"
        self.client = None
        self.db = None
        self.collection = None
        self.connect()

    def connect(self):
        try:
            self.client = MongoClient(self.MONGO_URI)
            self.db = self.client[self.MONGO_DB]
            self.collection = self.db[self.MONGO_COLLECTION]
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo conectar a MongoDB: {str(e)}")

    def close(self):
        if self.client:
            self.client.close()